#!/bin/sh

echo "Ville : "
read ville
curl wttr.in/$ville
